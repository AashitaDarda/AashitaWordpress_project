
<?php

function api_key_setting_callback_function( $val ) {
	$id = $val['id'];
	$option_name = $val['option_name'];
?>
	<input 
		type="tel" //this can be any HTML input type: date, number, text etc.
		name="<?php echo esc_attr( $option_name ) ?>"
		id="<?php echo esc_attr( $id ) ?>" 
		value="<?php echo esc_attr( get_option( $option_name ) ) ?>" // Displays the value stored in DB
	/> 
<?php
}
