<?php
add_filter( 'cron_schedules', 'check_daily' );
function check_daily( $schedules ) {
    $schedules['daily'] = array(
        'interval' => 86400,
        'display'  => __( 'Daily' ),
    );
    return $schedules;
}

// Unless an event is already scheduled, create one.
 
add_action( 'wp', 'openAi_custom_cron_job' );
 
function openAi_custom_cron_job() {
   if ( ! wp_next_scheduled( 'publish_post_daily' ) ) {
      wp_schedule_event( strtotime('6:00:00'), 'daily', 'publish_post_daily' );
   }
}

// Trigger publish post when hook runs
add_action( 'publish_post_daily', 'openAI_publish_article_hook' );
function openAI_publish_article_hook(){

	$message = "Post Published";
    $file = fopen("../custom_logs.log","a"); 
    fwrite($file, "\n" . date('Y-m-d h:i:s') . " :: " . $message);

	global $wpdb;
    $articles_table = $wpdb->prefix.'openAi_articles';
    $keywords_table	 = $wpdb->prefix.'openAi_keywords';
    $number_of_post = rand(1,5);
    $sql_query = $wpdb->get_results("SELECT * FROM $articles_table  ORDER BY rand() LIMIT $number_of_post");
    // $sql_query = $wpdb->get_results("SELECT * FROM $articles_table as a JOIN $keywords_table as k ON a.keyword_id = k.id  ORDER BY rand() LIMIT $number_of_post;");
    foreach ($sql_query as $result){
    	$id = $result->id;
    	$title = $result->title;
    	$content = $result->article;
    	$status = $result->status;
    	// $category = $result->topics;
    	// print_r($category);
    	// print_r($status);
    	echo '<br>';
    	if($status == '0'){
    		$arg = array(
    		  'post_title'=>$title, 
	          'post_type'=>'post', 
	          'post_content'=>$content,
	          // 'post_categories'=>$category,
	          'post_status'=>'publish'
    		);
    		$post = wp_insert_post($arg);
    		if($post){
    			// $status = '1'
    			$sql_update = $wpdb->query("UPDATE $articles_table SET status='1' WHERE id = '$id'");
    			echo '<div class="alert alert-success publish">Post Publish successfully</div>';
    			echo '<script>$(".publish").fadeOut(10000)</script>';
    		}
    	}
    	else{
    		echo '<div class="alert alert-danger not-publish">Post already published</div>';
    		echo '<script>$(".not-publish").fadeOut(10000)</script>';
    	}
    }
}

// do_action('publish_post_daily');
// die("working");
