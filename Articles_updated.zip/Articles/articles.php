<?php
/**
 * The Plugin Statred
 * 
 * @wordpress-plugin
 * 
 * Plugin Name: Open AI Articles
 * Description: This helps the open ai article to show on post.
 * Version: 1.0.0
 * Author: Aashita and Kushal
*/

/* if this file is called directly, abort. */

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
*/

if( ! defined( 'ABSPATH' ) ) exit;

require_once plugin_dir_path(__FILE__).'includes/scheduler.php';
require_once plugin_dir_path(__FILE__).'includes/post-scheduler.php';

add_action( 'admin_enqueue_scripts', 'enqueue_scripts_and_styles' );
function enqueue_scripts_and_styles(){
    wp_enqueue_style('boot-css',"https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css");

    wp_enqueue_style('jquery-css',"http://ajax.googleapis.com/ajax/libs/jqueryui/1/themes/base/jquery-ui.css");
    wp_enqueue_style('article-css',plugin_dir_url( __FILE__ ) . 'asset/css/article.css');

    wp_enqueue_script('ajax-js',"https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js");
    wp_enqueue_script('custom-js',plugin_dir_url( __FILE__ ) . 'asset/js/custom.js');

    wp_enqueue_script( 'ajaxHandle' );
    wp_localize_script( 
        'ajaxHandle', 
        'ajax_object', 
        array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) 
    );
}

// activate hook
register_activation_hook( __FILE__, 'activate_articles' );
function activate_articles(){
	
	require_once plugin_dir_path(__FILE__).'includes/class-articles-activator.php';
    Article_Activator::activate();
	
}

// deactivate hook
register_deactivation_hook( __FILE__, 'deactivate_articles' );
function deactivate_articles(){
	   require_once plugin_dir_path(__FILE__).'includes/class-articles-deactivator.php';
	Article_Deactivator::deactivate();
}

add_action( 'admin_menu', 'all_articles' );
function all_articles(){
    require( plugin_dir_path( __FILE__ ).'includes/class-all-articles.php' );
}


add_action( "wp_ajax_publishPost", "publishPost" );
add_action( "wp_ajax_nopriv_publishPost", "publishPost" );
function publishPost(){
    
   global $wpdb;
    $articles_table = $wpdb->prefix.'openAi_articles';
    $data = array(
        'status' => "1",
    );
    $where = array(
        'id' => $_POST['article_id']
    );
    $res_update = $wpdb->update( $articles_table, $data, $where );
    $title = $_POST['title'];
    $content = $_POST['Content'];
    $id = wp_insert_post(array(
          'post_title'=>$title, 
          'post_type'=>'post', 
          'post_content'=>$content,
          'post_status'=>'publish'
    ));

    if($id){
        $result['status']   = 200;
        $result['message']  = 'Publish Successfully';

    }else{
        $result['status']   = 404;
        $result['message']  = 'Something Went Wrong!! Please try again';
    }
    
    echo json_encode($result);
    exit();
}
