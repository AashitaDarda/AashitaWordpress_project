<?php

//If uninstall not called from wordpress, then exit.
if( ! defined( 'WP_UNINSTALL_PLUGIN' ) ){
	exit;
}