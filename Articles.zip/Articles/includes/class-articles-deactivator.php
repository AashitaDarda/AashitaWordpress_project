<?php
class Article_Deactivator{
	public static function deactivate(){
		// global $wpdb;
		// $articles_table = $wpdb->prefix.'openAi_articles';
		// $keywords_table	 = $wpdb->prefix.'openAi_keywords';
		// $sql_article = "DROP TABLE IF EXISTS $articles_table";
		// $sql_keyword = "DROP TABLE IF EXISTS $keywords_table";
		// $wpdb->query($sql_article);
		// $wpdb->query($sql_keyword);
	}
}