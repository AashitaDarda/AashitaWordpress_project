function DeleteFunction(){

	if (confirm("Are you sure you want to DELETE this Post!!!") == true) {
	} 
	else {
		event.preventDefault();
	}

}