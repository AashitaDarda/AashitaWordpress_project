<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @wordpress-plugin
 * Plugin Name:       Bug List
 * Plugin URI:        http://localhost/woocommerce/bug-list/
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Aashita
 * Author URI:        http://localhost/woocommerce
 */

//If this file is called directly, abort.
// if( ! defined( 'WPINC' ) ){
// 	die;
// }
if (!defined('ABSPATH')) exit;
/*
 * The code that runs during plugin activation.
 */

// function all_scripts(){
//     wp_register_script( 'jquery-core',"https://code.jquery.com/jquery-3.6.1.js",array( 'jquery' ),null,true );
//     wp_enqueue_script( 'jquery-core' );
//     wp_register_script( 'jquery-validate',"https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js",array( 'jquery' ),null,true );
//     wp_enqueue_script( 'jquery-validate' );
//     wp_register_script( 'validate',plugin_dir_url( __FILE__ ) . 'js/jquery-validate.js',array( 'jquery' ),null,true );
//     wp_enqueue_script( 'validate' );
// }

// add_action( 'wp_enqueue_scripts', 'all_scripts' );
function enqueue_scripts_and_styles(){
    wp_enqueue_style('boot-css',"https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css");

    // wp_enqueue_style('jquery-css',"http://ajax.googleapis.com/ajax/libs/jqueryui/1/themes/base/jquery-ui.css");

    wp_enqueue_style('style-css',plugin_dir_url( __FILE__ ) . 'css/style.css');

    // wp_enqueue_script('jquery-core',"https://code.jquery.com/jquery-3.6.1.js",array( 'jquery' ),null,false);

    wp_enqueue_script('ajax-js',"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js", array( 'jquery' ),null,false);

    // wp_enqueue_script('jquery-validate',"https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js",array( 'jquery' ),null,false);

    // wp_enqueue_script('validate',plugin_dir_url( __FILE__ ) . 'js/jquery-validate.js',array( 'jquery' ),null,false);


    wp_enqueue_script('boot-js',"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js", array( 'jquery' ),null,false);

    wp_enqueue_script('delete-js',plugin_dir_url( __FILE__ ) . 'js/validation.js');
}

add_action( 'admin_enqueue_scripts', 'enqueue_scripts_and_styles' );
    
function activate_bug_list(){
	
     if ( ! is_plugin_active( 'woocommerce/woocommerce.php' )) {
        // Stop activation redirect and show error
        wp_die('Sorry, but this plugin requires the Parent Plugin to be installed and active. <br><a href="' . admin_url( 'plugins.php' ) . '">&laquo; Return to Plugins</a>');
    }
    else{
        require_once plugin_dir_path(__FILE__).'inc/class-bug-list-activator.php';
        Bug_List_Activator::activate();

    }
}

/*
 * The code that runs during plugin deactivation.
 */
function deactivate_bug_list(){
	require_once plugin_dir_path(__FILE__).'inc/class-bug-list-deactivator.php';
	Bug_List_Deactivator::deactivate();
}
register_activation_hook( __FILE__, 'activate_bug_list' );
register_deactivation_hook( __FILE__, 'deactivate_bug_list' );

 /**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 */
 function bug_list_menu(){
 	
	require plugin_dir_path(__FILE__).'inc/class-all-bug-list.php';
 }
 add_action( 'admin_menu','bug_list_menu' );

 function short_code(){
 	require plugin_dir_path(__FILE__).'inc/class-bug-list.php';
 	// return true;
 }

 add_shortcode('bug-list-code','short_code');

 //Add a new tab as Bug list in my account page
/**
 * 1. Register new endpoint slug to use for My Account page
 */
function ts_custom_add_bug_list_endpoint() {
    add_rewrite_endpoint( 'bug-list', EP_ROOT | EP_PAGES );
}
  
add_action( 'init', 'ts_custom_add_bug_list_endpoint' );
  
  
/**
 * 2. Add new query var
 */
  
function ts_custom_bug_list_query_vars( $vars ) {
    $vars[] = 'bug-list';
    return $vars;
}
  
add_filter( 'woocommerce_get_query_vars', 'ts_custom_bug_list_query_vars', 0 );
  
  
/**
 * 3. Insert the new endpoint into the My Account menu
 */
  
function ts_custom_add_bug_list_link_my_account( $items ) {
    $items['bug-list'] = 'Bug List';
    return $items;
}
  
add_filter( 'woocommerce_account_menu_items', 'ts_custom_add_bug_list_link_my_account' );
  
  
/**
 * 4. Add content to the new endpoint
 */
  
function ts_custom_bug_list_content() {
    echo '<h3>WooCommerce Bug List</h3>';
    
    echo do_shortcode( ' [bug-list-code] ' );
}

/**
 * @important-note  "add_action" must follow 'woocommerce_account_{your-endpoint-slug}_endpoint' format
 */
add_action( 'woocommerce_account_bug-list_endpoint', 'ts_custom_bug_list_content' );

function reorder_account_menu( $items ) {
    return array(
            'dashboard'          => __( 'Dashboard', 'woocommerce' ),
            'orders'             => __( 'Orders', 'woocommerce' ),
            'downloads'          => __( 'Downloads', 'woocommerce' ),
            'edit-account'       => __( 'Account details', 'woocommerce' ),
            'bug-list'           => __( 'Bug List', 'woocommerce' ),
            'edit-address'       => __( 'Addresses', 'woocommerce' ),
            'customer-logout'    => __( 'Logout', 'woocommerce' ),
            'payment methods'    => __( 'Payment methods','woocommerce' )
    );

}
add_filter ( 'woocommerce_account_menu_items', 'reorder_account_menu' );
