<?php
	// echo '<h1>Welcome</h1>';
	$current_user = wp_get_current_user();
	$login_user=$current_user->user_login;
	// echo $login_user;
	if ( $login_user ) {
		global $wpdb;
		$table_name = $wpdb->prefix.'bug_list';
		$user_table = $wpdb->prefix.'users';

		//$bug_id = $_GET['bug_id'];
		// $sql = $wpdb->get_results("SELECT * FROM $table_name");
		$sql_join = $wpdb->get_results("SELECT * FROM $table_name INNER join $user_table on $table_name.developer=$user_table.ID WHERE user_login = '$login_user'");
		 //print_r($sql);		
?>
		<div class="file mx-5">
	    		<table class="w-100">
		    		<tr class="file">
			            <th class="w-5">ID</th>
			            <th class="w-20">Bug Name</th>
			            <th class="w-40">Bug Detail</th>
			            <th class="w-20">Status</th>
			            <!-- <th class="w-20">Assigned to</th> -->
			            <th class="w-10">Edit</th>
			            <!-- <th class="w-10">Delete</th> -->
				</tr>
				
	    	<?php 
			    	foreach($sql_join as $result){
			    		// $current_page_edit = admin_url("admin.php?page=edit-bug-list&b_id=" . $result->id); 
			    		// $current_page_delete = admin_url("admin.php?page=delete-bug-list&bug_id=" . $result->id); 
	    	?>
			        	
					<tr>
						<td class="file-id">
						    <?php echo $result->id; ?>
						</td>
						<td class="file-title">
						  <i class="fa fa-angle-right" aria-hidden="true"></i><h4><?php echo $result->name; ?></h4>
						</td>
						<td class="file-description">
							<?php echo $result->description; ?>
						</td>
						<!-- <td class="file-status">
							<?php echo $result->status; ?>
						</td> -->
						<td class="file-status">
							<?php echo $result->status;  ?>
							<!-- <select name="bug-status" class="bug_status">
								<option style="width:100px; height:44px;" value="<?php echo $result->status;  ?>">
									<?php echo $result->status;  ?>
								</option>  
							</select> -->
						</td>
						 
						<td>
						    <!-- <a href="#editModal" data-toggle="modal" id="edit_status" data-user_id="<?php echo $result->id; ?>">
						        <button  class="btn btn-primary btn-sm">Edit</button>  
						    </a> -->
						    <button class="btn btn-success" data-toggle="modal" data-target="#editModal<?php echo $result->id; ?>">Edit</button>
						</td>
					</tr>
					<div class="modal fade" id="editModal<?php echo $result->id; ?>" role="dialog"> 
						<div class="modal-dialog">   
							<div class="modal-content"> 
								<div class="modal-header d-flex justify-content-between"> 
									<div>
										<h4 class="modal-title">
											<b>Update status</b>
										</h4> 
									</div>
									<div>
										<button type="button" class="close" data-dismiss="modal">&times;</button> 
									</div>  
								</div> 
								<div class="modal-body">
									
									<form action="" method="POST" id="update_bug_form" class="mt-3 needs-validation" enctype="multipart/form-data" novalidate>
										<input type="text" name="bug_id" value="<?php echo $result->id; ?>" readonly style="width: 100%;height: 50px;">
										<div class="fetched_user">
											
											<div class="my-3">
												<select class="form-select" name="bug_status" id="exampleFormControlInput10" width=100% required>
													<option value="<?php  echo $result->status;?>"><?php echo $result->status;?></option>
													<!-- <option value=""> select bug status </option> -->
													<option value="Fixed">Fixed</option>
													<option value="Not Fixed">Not Fixed</option>
												</select>
											</div>
											<div class="modal-footer">
												<button type="submit" name="update_status" class="btn btn-info">Update</button>
											</div>
										</div> 
									</form>
								</div>  
							</div>
						</div>
					</div>
			<?php 
				} 
					
			?>
		    	</table> 		      
		</div>
			
<?php	



global $wpdb;
				$table_name = $wpdb->prefix.'bug_list';			
				if(isset($_POST['update_status'])){
					$bug_id=$_POST['bug_id'];
					$bug_status= $_POST['bug_status'];
					// print_r ($bug_id);
					$sql = "UPDATE $table_name SET status='$bug_status' WHERE id = '$bug_id'";
					$wpdb->query($sql);

					echo "You status is updated successfully";
					echo "<script>location.replace('http://localhost/woocommerce/my-account/bug-list/');</script>";
				}
?>
				<!-- <script>windows.location('http://localhost/woocommerce/my-account/bug-list/')</script> -->
<?php
	}


?>




