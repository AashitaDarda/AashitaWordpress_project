<?php

	add_menu_page('', 'Bug List', '', 'menu-bug', '','dashicons-buddicons-replies',22);

	add_submenu_page('menu-bug','All Bug List','All Bug List','manage_options','bug-list','all_buglist');

	add_submenu_page('menu-bug','Add New Bug','Add New Bug','manage_options','add-bug-list','add_new_bug');

	add_submenu_page('','','Edit Bug','manage_options','edit-bug-list','edit_bug');
	add_submenu_page('','','Delete Bug','manage_options','delete-bug-list','delete_bug');
?>

<?php 

	function all_buglist(){
		echo '<h1 class="bug display-4">All Bug List is here</h1>';
		global $wpdb;
		$table_name = $wpdb->prefix.'bug_list';
		$user_table = $wpdb->prefix.'users';

		//$bug_id = $_GET['bug_id'];
		// $sql = $wpdb->get_results("SELECT * FROM $table_name");
		$sql_join = $wpdb->get_results("SELECT * FROM $table_name INNER join $user_table on $table_name.developer=$user_table.ID");
		 //print_r($sql);		
?>
		<div class="file mx-5">
		    <a href="<?php echo "admin.php?page=add-bug-list" ?>">
		        <button class="btn btn-success mb-3">
		            Add New Bug
		        </button>
		    </a><hr>
	    		<table class="w-100">
		    		<tr class="file">
			            <th class="w-5">ID</th>
			            <th class="w-20">Bug Name</th>
			            <th class="w-40">Bug Detail</th>
			            <th class="w-20">Status</th>
			            <th class="w-20">Assigned To</th>
			            <th class="w-10">Actions</th>
			            
				</tr>
				
	    	<?php 
			    	foreach($sql_join as $result){
			    		$current_page_edit = admin_url("admin.php?page=edit-bug-list&b_id=" . $result->id); 
			    		$current_page_delete = admin_url("admin.php?page=delete-bug-list&bug_id=" . $result->id); 
	    	?>
			        	
					<tr>
						<td class="file-id">
						    <?php echo $result->id; ?>
						</td>
						<td class="file-title">
						  <i class="fa fa-angle-right" aria-hidden="true"></i><h3><?php echo $result->name; ?></h3>
						</td>
						<td class="file-description">
							<?php echo $result->description; ?>
						</td>
						<td class="file-status">
							<?php echo $result->status; ?>
						</td>
						<td class="file-status">
							<?php echo $result->user_login; ?>
						</td>
						<td class="d-flex justify-content-center">
						    <a href="<?php echo $current_page_edit;?>" class='mx-1'>
						        <button class="btn btn-primary btn-sm">Edit</button>  
						    </a>
						    <a href="<?php echo $current_page_delete;?>">
						        <button class="btn btn-danger btn-sm" onclick="DeleteFunction()">Delete</button>
						    </a>
						</td>
					</tr>
			<?php } ?>
		    	</table> 		      
		</div>
<?php
	}
	function add_new_bug(){
		echo '<h1 class="bug display-2">Add new bug</h1>';
?>
		<div class="container">
			<form action="" method="POST" id="add_bug_form" name="add_bug_form" class="mt-3 needs-validation" enctype="multipart/form-data" novalidate>
				<div class="mb-3">
					<label for="exampleFormControlInput1" class="form-label">Bug Name</label>
					<input type="text"  name="bug_title" class="form-control" id="exampleFormControlInput1" placeholder="enter your bug name" required>
				</div>

				<div class="mb-3">
					<label for="exampleFormControlInput2" class="form-label">Bug Description</label>
					<textarea  name="bug_description" class="form-control" id="exampleFormControlInput2"  required></textarea>
				</div>

				<div class="mb-3">
					<label for="exampleFormControlInput10" class="form-label">Bug Status </label><br>
					<select class="form-select" name="bug_status" id="exampleFormControlInput10" width=100% required>
						<option value=""> select bug status </option>
						<option value="Fixed">Fixed</option>
						<option value="Not Fixed">Not Fixed</option>
					</select>
				</div>

				<div class="mb-3">
					<label for="exampleFormControlInput10" class="form-label">Assigned To </label><br>
					<select class="form-select" name="bug_developer" id="exampleFormControlInput10" width=100% required>
						<option value=""> select developer </option>
						<option value="2">User 1</option>
						<option value="3">User 2</option>
					</select>
				</div>

				<div class="col-auto">
					<button type="submit" name="add_bug" class="btn btn-primary">Submit</button>
				</div>
			</form>
		</div>		
		
		<?php
			global $wpdb;
			$table_name = $wpdb->prefix.'bug_list';
			if(isset($_POST['add_bug'])){
				$bug_title = $_POST['bug_title'];
				$bug_des   = $_POST['bug_description'];
				$bug_status= $_POST['bug_status'];
				$bug_dev   = $_POST['bug_developer'];
				$sql = "INSERT INTO `$table_name`( `name`, `description`, `status`,`developer`) VALUES ('$bug_title','$bug_des','$bug_status','$bug_dev')";
				$wpdb->query($sql);

				echo "<h1> Your data is successfully submitted</h1>";
				echo "<script>location.replace('admin.php?page=bug-list');</script>";
			}

	}

	function edit_bug(){
		echo '<h1 class="bug display-4">Update your Bug here</h1>';
		global $wpdb;
		$bug_id = $_REQUEST['b_id'];
		$table_name1 = $wpdb->prefix.'bug_list';
		$myrows = $wpdb->get_results("SELECT * FROM $table_name1 where id='".$bug_id."'");

		// print_r($myrows);
?>
		<div class="container">
			<form action="" method="POST" id="update_bug_form" class="mt-3 needs-validation" enctype="multipart/form-data" novalidate>
				<div class="mb-3">
					<label for="exampleFormControlInput1" class="form-label">Bug Name</label>
					<input type="text"  name="bug_title" class="form-control" id="exampleFormControlInput1" value="<?php echo $myrows[0]->name;?>"  required>
				</div>

				<div class="mb-3">
					<label for="exampleFormControlInput2" class="form-label">Bug Description</label>
					<textarea  name="bug_description" class="form-control" id="exampleFormControlInput2"  required><?php echo $myrows[0]->description;?></textarea>
				</div>

				<div class="mb-3">
					<label for="exampleFormControlInput10" class="form-label">Bug Status </label><br>
					<select class="form-select" name="bug_status" id="exampleFormControlInput10" width=100% required>
						<option value="<?php echo $myrows[0]->status;?>"><?php echo $myrows[0]->status;?></option>
						<option value=""> select bug status </option>
						<option value="Fixed">Fixed</option>
						<option value="Not Fixed">Not Fixed</option>
					</select>
				</div>

				<div class="mb-3">
					<label for="exampleFormControlInput10" class="form-label">Assigned To </label><br>
					<select class="form-select" name="bug_developer" id="exampleFormControlInput10" width=100% required>
						<option value="<?php echo $myrows[0]->developer;?>"><?php echo $myrows[0]->developer;?></option>
						<option value=""> select developer </option>
						<option value="2">User 1</option>
						<option value="3">User 2</option>
					</select>
				</div>

				<div class="col-auto">
					<button type="submit" name="edit_bug" class="btn btn-info">Update</button>
				</div>
			</form>
		</div>		
<?php
			global $wpdb;
			$table_name3 = $wpdb->prefix.'bug_list';
			if(isset($_POST['edit_bug'])){
				$bug_title = $_POST['bug_title'];
				$bug_des   = $_POST['bug_description'];
				$bug_status= $_POST['bug_status'];
				$bug_devloper=$_POST['bug_developer'];
				$sql3 = "UPDATE $table_name3 SET name='$bug_title',description='$bug_des',status='$bug_status',developer='$bug_devloper' WHERE id = $bug_id";
				$wpdb->query($sql3);

				echo "<h1> Your data is successfully updated</h1>";
				echo "<script>location.replace('admin.php?page=bug-list');</script>";
			}
	}

	function delete_bug(){
		global $wpdb;
		$bugg_id = $_REQUEST['bug_id'];
		// print_r($bugg_id);
		$table_name2 = $wpdb->prefix.'bug_list';
		// print_r($table_name2);
		$myresult = $wpdb->query("DELETE FROM $table_name2 WHERE id='".$bugg_id."'");
		// print_r($myresult);
		// die();
		echo "<h1> Your data is successfully deleted</h1>";
		echo "<script>location.replace('admin.php?page=bug-list');</script>";
	}

	// function user_list_bug(){
	// 	require plugin_dir_path(__FILE__).'user/class-bug-list-function.php';
	// }
?>
