<?php
	class Bug_List_Deactivator{
		public static function deactivate(){
			global $wpdb;
			$table1 = $wpdb->prefix.'bug_list';
			$sql = "DROP TABLE IF EXISTS $table1";
			$wpdb->query($sql);
		}
	}
?>