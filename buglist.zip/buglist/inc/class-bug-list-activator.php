<?php
	class Bug_List_Activator {
		public static function activate(){
			global $wpdb;
			$db_table = $wpdb->prefix.'bug_list';
			$user_table = $wpdb->prefix.'users';
			//check to see if the table exists already, if not then create it 
			if($wpdb->get_var("show tables like '$db_table'")!= $db_table){
				$sql = "CREATE TABLE `$db_table` (
					`id` INT(11) NOT NULL AUTO_INCREMENT , 
					`name` VARCHAR(50) NOT NULL , 
					`description` VARCHAR(100) NOT NULL , 
					`status` VARCHAR(100) NOT NULL ,
					`developer` BIGINT(20) unsigned NOT NULL , 
					PRIMARY KEY (`id`)
				) ENGINE = InnoDB;";
				$sql_alter = "ALTER TABLE $db_table ADD FOREIGN KEY (developer) REFERENCES $user_table(ID);";
				$wpdb->query($sql);
				$wpdb->query($sql_alter);
			}
			
		}
	}
