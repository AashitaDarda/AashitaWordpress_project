jQuery('#add_bug_form').validate({
 		rules:{
 			bug_title:{
 				required:true,
 				minlength:3
 			},
 			bug_description:{
 				required:true,
 				maxlength:50
 			},
 			bug_status:{
 				required:true,
 			},
 			bug_developer:{
 				required:true,
 			},

 		},messages:{
 			bug_title:{
 				required:'Please Enter bug name',
 				minlength:'Bug name must be 3 char long'
 			},
 			bug_description:{
 				required:'Please enter bug description',
 				maxlength:"Bug can't be exceeding by 50"
 			},
 			bug_status:{
 				required:'Please select any one status'
 			},
 			bug_developer:{
 				required:'Please select any one developer'
 			},
 		}
 	});

 	jQuery('#update_bug_form').validate({
 		rules:{
 			bug_title:{
 				required:true,
 				minlength:3
 			},
 			bug_description:{
 				required:true,
 				maxlength:50
 			},
 			bug_status:'required',
 			bug_developer:'required'

 		},messages:{
 			bug_title:{
 				required:'Please Enter bug name',
 				minlength:'Bug name must be 3 char long'
 			},
 			bug_description:{
 				required:'Please enter bug description',
 				maxlength:"Bug can't be exceeding by 50"
 			},
 			bug_status:'Please select any one status',
 			bug_developer:'Please select any one developer'
 		}
 	});

