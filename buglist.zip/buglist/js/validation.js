function DeleteFunction(){

	if (confirm("Are you sure you want to DELETE this Post!!!") == true) {
	} 
	else {
		event.preventDefault();
	}

}

$(document).ready(function()
{    
	$('#editModal').on('show.bs.modal', function (e) 
	{        
		$('.fetched_user').html('Hello');
		// var user_id = $(e.relatedTarget).data('user_id');       
		// $.ajax(
		// {            
		// 	type : 'POST',            
		// 	url  : 'ajaxrequest/ajax_users.php?reg_id=<?= $regid ?>', //Here you will fetch records      
		// 	data    : 'user_id='+ user_id, //Pass $user_id            
		// 	success : function(result) 
		// 			{ 
		// 				//alert('success'+result); 
		// 				$('.fetched_user').html(result); //Show fetched data from database
		// 			},
		// 	error   : function(result) 
		// 			{ 
		// 				alert('error'+result); 
		// 			}
		// });     
	});
});